from PyQt5.QtWidgets import QApplication,QMainWindow,QPushButton,QWidget
import sys
from ogretmen_giris import girispage 

app = QApplication(sys.argv)
pencere = girispage()
pencere.show()
app.exec()

