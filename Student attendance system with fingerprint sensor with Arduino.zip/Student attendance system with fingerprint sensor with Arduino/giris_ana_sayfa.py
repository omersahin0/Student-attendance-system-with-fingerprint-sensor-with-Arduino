from PyQt5.QtCore import *
from ui_giris_ana_sayfa import Ui_MainWindow
from PyQt5.QtWidgets import QApplication,QMainWindow,QPushButton, QWidget

class ogretmengirispage(QMainWindow , Ui_MainWindow):
    def __init__(self):
        super().__init__()
        self.setupUi(self)
        self.setWindowTitle("Yönetici menü")
        self.anapencereform = Ui_MainWindow()
        


        self.icon_name_widget.setHidden(True)

        self.ogretmen1.clicked.connect(self.switch_to_ogretmen)
        self.ogretmen2.clicked.connect(self.switch_to_ogretmen)

        self.ogrenci1.clicked.connect(self.switch_to_ogrenci)
        self.ogrenci2.clicked.connect(self.switch_to_ogrenci)

        self.ders1.clicked.connect(self.switch_to_dersler)
        self.ders2.clicked.connect(self.switch_to_dersler)

        self.rapor1.clicked.connect(self.switch_to_raporlama)
        self.rapor2.clicked.connect(self.switch_to_raporlama)

        self.ayar1.clicked.connect(self.switch_to_ayarlar)
        self.ayar2.clicked.connect(self.switch_to_ayarlar)

        self.btncikis.clicked.connect(self.close)
        self.btntamekran.clicked.connect(self.toggle_fullscreen)
        self.btngrevcubukmod.clicked.connect(self.gorevcubukmodu)
    

    def toggle_fullscreen(self):
        if self.isFullScreen():
            self.showNormal()  # Tam ekrandan çık
        else:
            self.showFullScreen()  # Tam ekrana geç 

    def gorevcubukmodu (self):
        if self.isMaximized:
            self.showMinimized

        else :
            self.showMaximized 

    def switch_to_ogretmen(self):
        self.stackedWidget.setCurrentIndex(0)       
    
    
    def switch_to_ogrenci(self):
        self.stackedWidget.setCurrentIndex(1)

    def switch_to_dersler(self):
        self.stackedWidget.setCurrentIndex(2)

    def switch_to_raporlama(self):
        self.stackedWidget.setCurrentIndex(3)

    def switch_to_ayarlar(self):
        self.stackedWidget.setCurrentIndex(4)
           