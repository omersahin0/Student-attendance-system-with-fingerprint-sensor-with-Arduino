from PyQt5.QtCore import Qt
from PyQt5.QtWidgets import *
from PyQt5.QtWidgets import QWidget
from ui_ogretmen_giris import Ui_MainWindow
from giris_ana_sayfa import ogretmengirispage

class girispage(QMainWindow , Ui_MainWindow):
    def __init__(self) -> None:
        super().__init__()
        self.giris = Ui_MainWindow()
        self.giris.setupUi(self)
        self.ogretmenanasayfaac = ogretmengirispage()
        self.giris.pushButton.clicked.connect(self.girisyap)
        


    def girisyap(self):
        kadi = self.giris.lineEdit.text()
        sifre = self.giris.lineEdit_2.text()
        if kadi == 'admin' and sifre == '123' :
            self.ogretmenanasayfaac.show()
            self.hide()